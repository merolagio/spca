#change_sign======================

change_loadings_sign_spca = function(spca_obj, index_to_change) {
  if (!is.spca(spca_obj))
    stop("The first argument must be an spca object")
  if (!is.vector(index_to_change))
    stop(paste("index_to_change must be an integer or vector of indices",
               index_to_change, "was passed"))
  n = length(index_to_change)
  
  for (i in 1:n) {
    spca_obj$loadings[, index_to_change[i]] = 
      - spca_obj$loadings[, index_to_change[i]]
    
    spca_obj$contributions[, index_to_change[i]] = 
      - spca_obj$contributions[, index_to_change[i]]
    
    if (!is.null(spca_obj$loadingslist)) {
      spca_obj$loadingslist[[index_to_change[i]]] =
        - spca_obj$loadingslist[[index_to_change[i]]]
    }
    if (!is.null(spca_obj$scores))
      spca_obj$scores[, index_to_change[i]] =
      - spca_obj$scores[,index_to_change[i]]
    
    if (!is.null(spca_obj$spc_cor)) {
      spca_obj$spc_cor[index_to_change[i], ] =
        - spca_obj$spc_cor[index_to_change[i], ]
      spca_obj$spc_cor[, index_to_change[i]] = 
        - spca_obj$spc_cor[, index_to_change[i]]
    }
  }
  return(spca_obj)
}

#spca() =============
out = list(loadings = spout$loadings,
           contributions = contributions,
           n_comps = spout$n_comps,
           cardinality = spout$card,
           vexp = spout$vexp,
           vexp_pc = spout$vexp_pc[1:n_comps],
           cvexp = spout$cvexp,
           rvexp = rvexp,
           rcvexp = rcvexp,
           sq_cor_with_pc = spout$r2,
           tot_var = spout$totvar,
           loadings_list = spout$loadlist,
           indices = spout$ind
)
## FIX TIME NAMES
if (use_fat_backend) {
  out$scores = spout$scores
  if (n_comps > 1){
    out$spc_cor = cor(spout$scores)
    colnames(out$spc_cor) = paste0("sPC", seq_len(spout$n_comps))
    rownames(out$spc_cor) = paste0("sPC", seq_len(spout$n_comps))
  }
  out$parameters = parameters
  out$time_wall = spout$Time_wall
  out$time_colnames = spout$Time_colnames
  out$setup_wall = spout$setup_wall
  out$setup_cpu = spout$setup_cpu
  out$time_unit_raw = spout$time_unit_raw
}
else {
  # check if exist both scores and spc_cor add to cpp (done in thin but not checked) add to docs
  
  if ((is_datamatrix_M)) {
    out$scores = abC(M, spout$loadings[, seq_len(spout$n_comps), 
                                       drop = FALSE])
    
    colnames(out$scores) = paste0("sPC", seq_len(spout$n_comps))
    if (n_comps > 1){
      out$spc_cor = cor(out$scores)
      colnames(out$spc_cor) = paste0("sPC", seq_len(spout$n_comps))
      rownames(out$spc_cor) = paste0("sPC", seq_len(spout$n_comps))
    }
  }
  else{
    out$scores = NULL
    if (n_comps > 1){
      out$spc_cor = make_spc_cor_S(spout$loadings, S)
    }
    else 
      out$spc_cor = NULL
  }
  colnames(spout$Time) = spout$Time_colnames
  out$parameters = parameters
  out$time = spout$Time
  out$time_vec = spout$time_vec
  out$time_comp = spout$time_comp
}
out$call = match.call()
class(out) = c(class(out), "spca")
return(out)
}




#pca()===========================
out = list(loadings = loadings[, 1:n_comps, drop = FALSE],
           contributions = contributions,
           n_comps = n_comps,
           cardinality = rep(p, n_comps),
           vexp = vexp,
           vexp_pc = vexp,
           cvexp = cumsum(vexp),
           rvexp = rep(1, n_comps),
           rcvexp = rep(1, n_comps),
           sq_cor_with_pc = rep(1, n_comps),
           tot_var = pcout$totvar,
           loadings_list = loadings_list,
           indices = as.list(rep(list(1:p), n_comps)),
           eigenvalues = pcout$eigenvalues[seq_len(min(rank_M, length(pcout$eigenvalues)))]
)
#new_spca==============

obj = list()
obj$loadings = A
obj$contributions = make_contributions(A)
dimnames(obj$contributions) = dimnames(A)
obj$n_comps = ncol(A)
obj$cardinality = colSums(A != 0)



tmp_vexp = make_vexpSC(obj$loadings, S)  
s_ee = eigen(S)
totv = sum(s_ee$values)
obj$vexp = tmp_vexp$vexp/totv
obj$vexp_pc = s_ee$values[1:obj$n_comps]/totv
obj$cvexp = tmp_vexp$cvexp/totv
obj$rvexp = obj$vexp/obj$vexp_pc
obj$rcvexp = obj$cvexp/cumsum(obj$vexp_pc)
obj$sq_cor_with_pc = var2corC(atdbC(A, S, s_ee$vectors[, seq_len(obj$n_comps)]))
obj$tot_var = totv

obj$indices = list()
obj$loadings_list = list()
for(i in 1:obj$n_comps){
  obj$indices[[i]] = which(A[, i] != 0)
  obj$loadings_list[[i]] = A[obj$indices[[i]], i]
  names(obj$indices[[i]]) = rownames(A)[obj$indices[[i]]]
  names(obj$loadings_list[[i]]) = rownames(A)[obj$indices[[i]]]
}

if(!is.null(X)){
  obj$scores = abC(X, A)
  obj$spc_cor = makeCorScoresC(obj$scores)
}
else{
  obj$spc_cor = make_corComp_S(A, S)
}

if(!is.null(methods_names))  
  obj$methods_names = methods_names

class(obj) = c("list", "spca")

return(obj)
}
