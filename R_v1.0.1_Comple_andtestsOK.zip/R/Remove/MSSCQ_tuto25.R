

# Answers to the Multidimensional Sexual Self-Concept Questionnaire. 	
# 100 likert rated items, gender, age 	1
# 7685 	MSSCQ
# 20 scales

fnm = file.path("C:/Users/merol/Dropbox/Papers/Spca_tutorial_paper/paper2025_Tutorial/Data/openPsychometrics/Multidimensional Sexual Self-Concept/MSSCQ/MSSCQ_data.csv")

dim(MS)
colnames(MS)
MS_demo = MS[, 101:102]
table(MS$SAN_I2)

numzeros = apply(MS[, 1:100] ==0, 1, sum)
summary(numzeros)
mean(numzeros > 0)
table(numzeros[numzeros>5])

sum(numzeros > 3)
summary(MS$age[numzeros>0])
cnumzeros = apply(MS[, 1:100] ==0, 2, sum)
sum(cnumzeros==0)
table(cnumzeros)
rm(MS)
#read lookup------------------
fnm = file.path("C:/Users/merol/Dropbox/Papers/Spca_tutorial_paper/paper2025_Tutorial/Data/openPsychometrics/Multidimensional Sexual Self-Concept/MSSCQ/MSSCQ_lookup.csv")

MS_lookup = read.csv(file = fnm, sep = ",", as.is = T)
dim(MS_lookup)
unique(MS_lookup$Scale)
names(MS_lookup)
Encoding(MS_lookup$ItemQuestion) <- "latin1"
ii = which(grepl("(R)", MS_lookup$ItemQuestion))
MS_lookup[ii,]

##reverse questions================
rm(MSSCQ_reverse)
MS_reverse <- c(27, 47, 68, 77, 88, 97)

for(k in MS_reverse) MS[, k] = 6 - MS[, k]

MS_scale_list <- list(
  sexual_anxiety                 = c(1, 21, 41, 61, 81),
  sexual_self_efficacy           = c(2, 22, 42, 62, 82),
  sexual_consciousness           = c(3, 23, 43, 63, 83),
  motivation_to_avoid_risky_sex  = c(4, 24, 44, 64, 84),
  chance_luck_sexual_control     = c(5, 25, 45, 65, 85),
  sexual_preoccupation           = c(6, 26, 46, 66, 86),
  sexual_assertiveness           = c(7, 27, 47, 67, 87),
  sexual_optimism                = c(8, 28, 48, 68, 88),
  sexual_problem_self_blame      = c(9, 29, 49, 69, 89),
  sexual_monitoring              = c(10, 30, 50, 70, 90),
  sexual_motivation              = c(11, 31, 51, 71, 91),
  sexual_problem_management      = c(12, 32, 52, 72, 92),
  sexual_esteem                  = c(13, 33, 53, 73, 93),
  sexual_satisfaction            = c(14, 34, 54, 74, 94),
  power_other_sexual_control     = c(15, 35, 55, 75, 95),
  sexual_self_schemata           = c(16, 36, 56, 76, 96),
  fear_of_sex                    = c(17, 37, 57, 77, 97),
  sexual_problem_prevention      = c(18, 38, 58, 78, 98),
  sexual_depression              = c(19, 39, 59, 79, 99),
  internal_sexual_control        = c(20, 40, 60, 80, 100)
)
names(MS_scale_list)

ms_scale_names = names(ms_scale_list)

ms_scalesh_names = unique(MS_lookup$scaleSH)
# c("SAN", "SSE", "SC", "MTA", "CLS", "SP", "SAS", "SO", "SPS", "SMN", "SMT", "SPM", "SE", "SS", "POS", "SSS", "FOS", "SPP", "SD", "ISC")

MS_scalesh_list = MS_scale_list
names(MS_scalesh_list) = ms_scalesh_names

ms_scale_fac = factor(rep(1:20, each = 5), labels = ms_scale_names)
ms_scalesh_fac = factor(rep(1:20, each = 5), labels = ms_scalesh_names)
ms_scale_list
##sort cols----------------
n_ms = nrow(MS)
n_ms
colnames(msc)
names(MS)[98:102]
anyna(MS)
names(MS)
#sort MS=============

MS = MS[, c(unlist(MS_scale_list), 101:102)]
colnames(MS)
colnames(MS)[1:100] = 
paste(MS_lookup$scaleSH, paste0("I", 1:100), sep = "_")
View(MS_lookup)

##make scale names----------------------
ms_scale_fac = factor(rep(1:20, each = 5), labels = ms_scale_names)
ms_scale_list = lapply(1:20, function(i) (1:5) + 5*(i - 1))
names(ms_scale_list) = ms_scale_names

ms_scalesh_fac = factor(rep(1:20, each = 5), labels = ms_scale_names)
ms_scalesh_list = lapply(1:20, function(i) (1:5) + 5*(i - 1))
names(ms_scalesh_list) = ms_scalesh_names 


##scale vars-----------------
MS_vars = apply(MS[, 1:100], 2, var)
dfvar = data.frame(Item = forcats::as_factor(colnames(MS)[1:100]), variance = MS_vars, Scale = MS_lookup$scaleSH)

ggplot(dfvar, aes(Item, y = variance, fill = Scale)) + geom_bar(stat = "identity", position = "dodge") + theme(axis.text.x = element_text(angle = 90))

msc = scale(MS[, 1:100], scale = F)
colnames(MS)
colnames(msc) = colnames(MS)[1:100]

ms_v = var(msc)

p_ms = ncol(msc)

mss = scale(MS[, 1:100])
ms_r = cor(msc)

ms_scale_list[[1]]

ms_corplot = plotcor4(ms_r, vargroup_list = ms_scale_fac, separateblocks = T, blocknames = ms_scalesh_names, blocknamesface = "bold", rtn = T)#, blocknamessize = 

tuto_save("ms_corplot")
colnames(ms)

gg <- ms_r[upper.tri(ms_r)]
summary(gg)
summary(abs(gg))


save(list = c("MS", "ms_demo", "MS_lookup","ms_scale_fac", "ms_scale_list", "ms_scale_names", "ms_scalesh_fac", "ms_scalesh_list", "ms_scalesh_names"), file = "MS_basic.Rdata")
#eigen V=======================
msv_ee = eigen(ms_v, symmetric = T)
rox(msv_ee$values[1:30], 1)
rox(msv_ee$values[1:30]/sum(msv_ee$values), 2)
rox(100*cumsum(msv_ee$values[1:30])/sum(msv_ee$values), 1)
plot(rox(apply(msc, 2, sd), 2))

dim(msc)
wachterqq(msv_ee$values, p = p_ms, n = n_ms)

plot(1:p_ms, msv_ee$values, pch = 16)
#Eigen R===========

msr_ee = eigen(ms_r, symmetric = T)
rox(msr_ee$values[1:30], 1)
rox(msr_ee$values[1:30]/sum(msr_ee$values), 2)
rox(100*cumsum(msr_ee$values[1:30])/sum(msr_ee$values), 1)
plot(rox(apply(ms, 2, sd), 2))

args(scree_watc_plot)
scree_watc_plot(msr_ee$values, n = nrow(msc), wa_nfit_line = 96, wa_cor = F)

#PCA V==============
colnames(msc)

msv_pca = SPCA2::pca(ms_v, ncomps = 4 )
colnames(ms_v)
summary(msv_pca)
p2 = SPCA2:::plot.spca(msv_pca, returnplot = T, vargroups = ms_scalesh_fac, colourscale = "bw", produceplot = F)
args(SPCA2:::plot.spca)

rownames(msv_pca$loadings)
sapply(ms_scale_list, length)
#2) Add the vertical lines to your existing plot p
cuts = seq(5, 95, 5) + 0.5
#p3 <- 
p2 + ggplot2::geom_vline(xintercept = cuts, linewidth = 0.5, colour = "red") + theme(axis.text.x = element_text(angle = 90))

#PCA R==============

msr_pca = SPCA2::pca(ms_r, ncomps = 4 )
colnames(ms_r)  
summary(msr_pca)

p3 = SPCA2:::plot.spca(msr_pca, returnplot = T, vargroups = ms_scalesh_fac, colourscale = "bw", produceplot = F)

cuts = seq(5, 95, 5) + 0.5
#p3 <- 
p3 + ggplot2::geom_vline(xintercept = cuts, linewidth = 0.5, colour = "red") + theme(axis.text.x = element_text(angle = 90))

#
#spca =================
#very slow 17k obs x 100 vars
##spca 95=================

msc_pspcap95 = pspca2(msc, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "f", scalex = FALSE) 

colnames(msc)
rownames(msc_pspcap95$contributions) = colnames(msc)
rownames(msc_pspcap95$loadings) = colnames(msc)

summary(msc_pspcap95)   
capture.output(
#SPCA2:::print.spca(msc_pspcap95, cols = 1:4), file = "msc_pspca_95_loads.csv"
"msc_pspca_95_loads.csv"
)
rownames(msc_pspcap95$contributions)[1:10]
write.table(msc_pspcap95$contributions, file = "msc_pspca_95_cont.csv", row.names = T, sep = "\t")

write.table(msv_pca$contributions, file = "msc_pca_cont.csv", row.names = T, sep = "\t")
msc_pspcap95_load_pl = SPCA2:::plot.spca(msc_pspcap95, nplot = 4, onlynonzero = T, legendPosition = "none", vargroups = af, colourscale = "bcc", returnplot = T, produceplot = F)   
msc_pspcap95_load_pl
args(SPCA2:::plot.spca)
objects(pattern = "^ms")

#p2 = SPCA2:::plot.spca(msv_pca, returnplot = TRUE, vargroups = ms_scale_fac, colourscale = "bw", produceplot = F)

args(SPCA2:::plot.spca)

msc_pspcap95_load_pl 

#2) Add the vertical lines to your existing plot p
#cuts = seq(5, 95, 5) + 0.5
#p3 <- 
#+ ggplot2::geom_vline(xintercept = cuts, linewidth = 0.5, colour = "red") + theme(axis.text.x = element_text(angle = 90))

##spca 90------------------
msc_pspcap90 = pspca2(msc, alpha = 0.90, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "seqrep", scalex = FALSE) 

summary(msc_pspcap90)   
SPCA2:::print.spca(msc_pspcap90, cols = 1:4)

msc_pspcap90_load_pl = SPCA2:::plot.spca(msc_pspcap90, nplot = 4, onlynonzero = F, legendPosition = "bottom", vargroups = ms_scale_fac, colourscale = "bw", 
                                         returnplot = T, produceplot = F)   

cuts = seq(5, 90, 5) + 0.5

msc_pspcap90_load_pl + ggplot2::geom_vline(xintercept = cuts, linewidth = 0.5, colour = "red")

fn = "Tables/msc_pspcap95_quest.txt"

write_items.spca(rmsc_pspcap95, filename = fn, MS_lookup, contrib = T)


#fewer scales==============
#take 13 to 17


rms_scale_list = ms_scale_list[1:5]
rms_scale_names = ms_scale_names[13:17]
rms_scale_fac = droplevels(ms_scale_fac[61:85])
rms_ind = unlist(ms_scale_list[13:17])

rmsc = msc[, rms_ind]
rms_r = ms_r[rms_ind, rms_ind] 
rms_v = ms_v[rms_ind, rms_ind] 

plotcor4(rms_r, vargroup_list = rms_scale_list, separateblocks = T, blocknames = rms_scale_names, addlabels = T)

##eigen======

rmsv_ee = eigen(rms_v, symmetric = T)
rox(rmsv_ee$values[1:4])
rox(rmsv_ee$values/sum(rmsv_ee$values))
rox(cumsum(rmsv_ee$values)/sum(rmsv_ee$values))

plot(rmsv_ee$values, pch = 16)
wachterqq(rmsv_ee$values, n = n_ms, p = ncol(rmsc), cor = F, fit_line = 4) 

##PCA V============

rmsv_pca = SPCA2::pca(rms_v, ncomps = 4 )

SPCA2:::plot.spca(rmsv_pca, returnplot = T, vargroups = rms_scale_fac, colourscale = "cbb")
args(SPCA2:::plot.spca)

##spca---------------------
rmsc_pspcap95 = pspca2(rmsc, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "seqrep", force.in = NULL, force.out = NULL, selectfromthese = NULL, lsspca_forLasso = TRUE, lambda = 0.2, scalex = FALSE) 

summary(rmsc_pspcap95)   
MS_lookup[rmsc_pspcap95$ind[[1]], ]
colnames(rmsc)
rownames(rmsc_pspcap95$loadings) = colnames(rmsc)
rownames(rmsc_pspcap95$contributions) = colnames(rmsc)


SPCA2:::print.spca(rmsc_pspcap95, cols = 1:4)
rmsc_pspcap95$ncomp


fn = "rmsc_pspcap95_quest.txt"

write_items.spca(rmsc_pspcap95, filename = fn, MS_lookup, contrib = T)

SPCA2:::plot.spca(rmsc_pspcap95, nplot = 4, onlynonzero = T, legendPosition = "bottom", vargroups = rms_scale_fac)  


write_items.spca(rmsc_pspcap95, "tmp.txt", MS_lookup, contrib = T)




