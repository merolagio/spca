SOURCE-OF-TRUTH LOCK:
  Use only this file: C:/.../spca_v1.6.R.
Ignore all previous versions and all previous discussion.
Before editing, quote the exact block you will replace.
Do not change validation.
Do not use remembered code.
Save a modified copy only in C:/.../Codex/...