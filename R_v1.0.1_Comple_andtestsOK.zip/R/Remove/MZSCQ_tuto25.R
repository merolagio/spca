MSSCQ

#MS and all files with names, scales, lookup
#MS already questions reversed and column sorted
load( "msc_basic.Rdata", verbose = T)
load( "MZ_allobjects.Rdata", verbose = T)

numzeros = apply(MS[, 1:100] ==0, 1, sum)
summary(numzeros)
mean(numzeros > 0)
table(numzeros[numzeros>5])

sum(numzeros > 3)#700
mean(numzeros > 3)#4%
indzeros = which(numzeros > 3)


length(indzeros)
MZ = MS[-indzeros, ]
names(MZ)
zz = rowSums((MZ == 0))
table(zz)
table(MZ$age[zz > 0])


##scale vars-----------------
# MZ_vars = apply(MZ[, 1:100], 2, var)
# 
# dfvar = data.frame(Item = forcats::as_factor(colnames(MZ)[1:100]), variance = MZ_vars, Scale = MS_lookup$scaleSH)
# 
# ggplot(dfvar, aes(Item, y = variance, fill = Scale)) + geom_bar(stat = "identity", position = "dodge") + theme(axis.text.x = element_text(angle = 90), legend.position = "none")

#make matrice==============

mz_demo = MZ[, 101:102]

mz_n = nrow(mzs)
mz_p = ncol(mzs)

# mzc = scale(MZ[, 1:100], scale = F)
# colnames(mzc) = colnames(MZ)[1:100]
# mz_v = var(mzc)
mzs = scale(MZ[, 1:100])
colnames(mzs) = colnames(MZ)[1:100]
mz_r = cor(mzs)

#corplot---------------------------
mz_corplot_pl = plotcor4(mz_r, vargroup_list = ms_scale_fac, separateblocks = T, expandTop = 0.05, blocknames = ms_scalesh_names, blocknamesvjust = -0.5, blocknamessize = 4,  side_axis_labels =  F, rtn = T, plt = T)

mz_corplot_pl 
 tuto_save(plname = "mz_corplot_pl", w = 8, h = 8)
 #+  #theme(plot.margin = unit(c(top = 2, right = 1, bottom = -1, left = 1), "lines")) + 
#   scale_y_discrete(expand = expansion(mult = c(0.025, 0.1))) + 
#   coord_cartesian(clip = "off") #


# gg <- mz_r[upper.tri(mz_r)]
# summary(gg)
# summary(abs(gg))


save(list = c("MZ", "mz_demo", "MS_lookup","ms_scale_fac", "ms_scale_list", "ms_scale_names", "ms_scalesh_fac", "ms_scalesh_list", "ms_scalesh_names"), file = "MZ_basic.Rdata")
#Eigen R===========

mzr_ee = eigen(mz_r, symmetric = T)
rox(mzr_ee$values[1:30], 1)
rox(100*mzr_ee$values[1:30]/sum(mzr_ee$values), 1)
rox(100*cumsum(mzr_ee$values[1:30])/sum(mzr_ee$values), 1)

args(scree_watc_plot)
mz_scree_wact_pl = scree_watc_plot(mzr_ee$values, n = mz_n, wa_nfit_line = 96, wa_cor = T)
mz_scree_wact_pl
tuto_save(plname = "mz_scree_wact_pl", w = 12, h = 6)


#PCA==============

mzs_pca = SPCA2::pca(mzs, ncomps = 4 )
summary(mzs_pca)


mzs_pca_contr_pl = SPCA2:::plot.spca(mzs_pca, returnplot = T, vargroups = ms_scalesh_fac, varnames = F, colourscale = "ggplot", legendPosition = "right", stripnames = paste("Component", 1:4), produceplot = F, )

mzs_pca_contr_pl = mzs_pca_contr_pl + scale_y_continuous(labels = scales::percent) + labs(x = "item")

# mzs_pca_contr_pl

tuto_save("mzs_pca_contr_pl", w = 10, h = 4)


#SPCA===================
#slow 17k obs x 100 vars
library(SPCA2)
mzs_pspcas95 = pspca2(mzs, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "s", scalex = FALSE) 

mzs_pspcas90 = pspca2(mzs, alpha = 0.90, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "s", scalex = FALSE) 

SPCA2:::summary.spca(mzs_pspcas95, cols = 1:2)
summary(mzs_pspcas90)

mzs_pspcas90_load_pl = SPCA2:::plot.spca(mzs_pspcas90, nplot = 4, onlynonzero = T, varnames = F, legendPosition = "right", vargroups = ms_scalesh_fac, colourscale = "ggplot", returnplot = T, produceplot = F)  + scale_y_continuous(labels = scales::percent) + labs(x = "item")

mzs_pspcas90_load_pl

summary(mzs_pspcas95)
summary(mzs_pspcas90)
mz_p

13/100

##plot loads------------------------

mzs_pspcas95_2Contr_pl = plot(mzs_pspcas95, nplot = 2, varnames = F, vargroups = ms_scalesh_fac, onlynonzero = F, plottype = "b", colourscale = "ggplot", legendPosition = "right", returnplot = T, produceplot = F)  + scale_y_continuous(labels = scales::percent) + labs(x = "item")

mzs_pspcas95_2Contr_pl

tuto_save("mzs_pspcas95_2Contr_pl", w = 16, h = 4)

ms_sc

mzs_pspcas95_contr_pl = SPCA2:::plot.spca(mzs_pspcas95, nplot = 4, onlynonzero = T, varnames = F, stripnames = paste("Component", 1:4), legendPosition = "right", vargroups = ms_scalesh_fac, colourscale = "ggplot", returnplot = T, produceplot = F)  + scale_y_continuous(labels = scales::percent) + labs(x = "item") 

mzs_pspcas95_contr_pl


tuto_save("mzs_pspcas95_contr_pl", w = 10, h = 5)

mzs_pspcas95_2Scoreplot_pl = SPCA2::plot_scores(scorelist = mzs_pspcas95$scores, pcs = mzs_pca$scores,  nplot = 2, methodsnames = "pSPCA 95%", addcor = T, linesize = 1, pointsize = 0.6, textsize = 7, rtn = T)

tuto_save("mzs_pspcas95_2Scoreplot_pl", h = 4.5)


##Tables-----------------------

  
ms_scales  
  

###aggregated=======================




A = matrix(0, 100, 12)
for(i in 1:4){
  A[, (1:3) + 3*(i - 1)] = cbind(mzs_pca$contributions[, i], mzs_pspcas95$contributions[, i], mzs_pspcas90$contributions[, i])
}
dim(A)
length(ms_scalesh_fac)

A = as.data.frame(A)

mzs_aggreg_contr = rox(aggregate_by_scale(A, ms_scalesh_fac), 3)
colnames(mzs_aggreg_contr) = paste0(rep(c("PCA", "SPCA 95%", "SPCA 90%"), 4), rep(1:4, each = 3))

write.table(mzs_aggreg_contr, file = "clipboard", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

M = mzs_aggreg_contr[, c(1,4,7)]  
M
rox(sort(M[,1]), 0)
rox(tapply(M[,1], M[, 1] < 0, sum), 0)

k = 2
rox(sort(M[,k]), 0)
rox(tapply(M[,k], M[, k] < 0, sum), 0)

N = rox(cor(cbind(mzs_pspcas95$scores, mzs_pspcas90$scores)))
Np = rox(cor(mzs_pca$scores, cbind(mzs_pspcas95$scores, mzs_pspcas90$scores)))

write.table(rbind(N, diag(Np)), file = "clipboard", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)



##contr 1-2-----------------

ind195 = sort(mzs_pspcas95$ind[[1]])
ind295 = sort(mzs_pspcas95$ind[[2]])
intersect(ind195, ind295)
MS_lookup[77, ]
ind190 = sort(mzs_pspcas90$ind[[1]])
ind290 = sort(mzs_pspcas90$ind[[2]])
intersect(ind190, ind290)


inda95 = sort(unique(unlist(mzs_pspcas95$ind[1:2])))
inda90 = sort(unique(unlist(mzs_pspcas90$ind[1:2])))
length(inda95)
length(inda90)

#file with both 95 and 90
inda = sort(union(inda95, inda90))
length(inda)

B = matrix(0, 100, 6)
for(i in 1:2){
  B[, (1:3) + 3*(i - 1)] = cbind(rox(cbind(mzs_pca$contributions[, i], mzs_pspcas95$contributions[, i], mzs_pspcas90$contributions[, i])))
}
colnames(B) = paste0(rep(c("PCA", "SPCA 95%", "SPCA 90%"), 2), rep(1:2, each = 3))
B = as.data.frame(B[inda, ])
B[1:10,]

B = as.data.frame(rox(cbind(mzs_pca$contributions[, 1:2], mzs_pspcas95$contributions[, 1:2], mzs_pspcas90$contributions[, 1:2])[inda, ]))

names(MS_lookup)
#A = MS_lookup[inda, 1:3]
A = cbind(Item = MS_lookup[inda, 1], scale = MS_lookup[inda, 4], B)
rownames(A) = NULL
mzs_contr_12_table = A


write.table(A, "clipboard", sep = "\t", row.names = FALSE, col.names = TRUE, quote = FALSE)

D = cbind(summary(mzs_pca, cols = 1, rtn = T, prn = F), summary(mzs_pspcas95, cols = 1, rtn = T, prn = F), summary(mzs_pspcas90, cols = 1, rtn = T, prn = F),
summary(mzs_pca, cols = 2, rtn = T, prn = F)[, 2], summary(mzs_pspcas95, cols = 2, rtn = T, prn = F)[, 2], summary(mzs_pspcas90, cols = 2, rtn = T, prn = F)[, 2])


D
write.table(D, "clipboard", sep = "\t", row.names = FALSE, col.names = TRUE, quote = FALSE)

summary(mzs_pspcas95, cols = 4, rtn = F, prn = T)

D = cbind(summary(mzs_pca, cols = 4, rtn = T, prn = F)[, 3], summary(mzs_pspcas95, cols = 4, rtn = T, prn = F)[, 3], summary(mzs_pspcas90, cols = 4, rtn = T, prn = F)[, 3],
      summary(mzs_pca, cols = 4, rtn = T, prn = F)[, 4], summary(mzs_pspcas95, cols = 4, rtn = T, prn = F)[, 4], summary(mzs_pspcas90, cols = 4, rtn = T, prn = F)[, 4])

D
write.table(D, "clipboard", sep = "\t", row.names = FALSE, col.names = TRUE, quote = FALSE)


fln = "Tables/mzs_pspca_95_cont_1nd2.csv"
write.table(A, file = fln, row.names = F, sep = "\t")
write.table(x = "Summaries", file = fln, append = T, row.names = F, col.names = F)
write.table(D, file = fln, row.names = T, sep = "\t", append = T)

#file with only 95 

#primi 2 loads=====================
inda95 = sort(unique(unlist(mzs_pspcas95$ind[1:2])))

fln = "Tables/mzs_pspca_95_2cont.csv"
write.table(cbind(MS_lookup[inda95, 1:3], mzs_pspcas95$contributions[inda95, 1:2]), file = fln, row.names = F, sep = "\t")
write.table(x = "Summaries", file = fln, append = T, row.names = F, col.names = F)
write.table(summary(mzs_pspcas95, cols = 1:2, rtn = T, prn = F), file = fln, row.names = T, sep = "\t", append = T)

#abess spca ================

mzs_abess = abess::abesspca(mz_r, type = "predictor", sparse.type = "kpc", 
                            cor = F, kpc.num = 4)#, support.size = rep(1:20, 6))  

dim(mzs_abess$coef[[1]])
length(mzs_abess$coef)
#abess::extract()


dim(mzs_abess$coef[[1]])
colSums(abs(as.matrix(mzs_abess$coef[[1]])) > 0)
mzs_abess$coef[[2]]

msc_pspcap95$card
objects(pattern = "^ms")


cc = sapply(1:4, function(i, ab, sp) ab[[i]][, sp[i]],
            ab = mzs_abess$coef, sp = mzs_pspcas95$card)
mzs_p
dim(cc)
ind1 = which(mzs_pspcas95$contributions[, 1] != 0)
length(ind1)
inda1 = which(cc[, 1] != 0)
length(inda1)


rox(cbind(mzs_pspcas95$loadings[, 1], cc[, 1]))

rox(cbind(mzs_abess$coef[[1]][, 10], mzs_abess$coef[[2]][, 8]))
colSums(abs(cc)> 0)

View(cc)

#cc = -cc
args(SPCA2::new_spca)
mzs_abess.spca =  SPCA2::new_spca(cc, mz_r, mzs, method = "abess")
names(mzs_abess.spca)
#mzs_abess.spca$vif

rox(cor(mzs_abess.spca$scores))
SPCA2:::plot.spca(mzs_abess, onlynonzero = F)
class(mzs_abess.spca)
summary(mzs_abess.spca)

plot(mzs_abess.spca, colourscale = "ggplot", vargroups = ms_scalesh_fac)
length(ms_scale_list)
MS_lookup[mzs_abess.spca$ind[[1]], ]
dim(MS_lookup)
bb = tcrossprod(x, t(aa))
dim(bb)
sum((rmsc)^2)
rox(cor(mzs_abess.spca$scores))

##aggregated by scale====================

A = matrix()
length(mzs_abess.spca)
mzs_aggrContr = make_contByscale(mzs_abess.spca$contributions, ms_scalesh_fac)  

mzs_aggrContr
K = matrix(0, 20, 4)
i = 1
for(i in 1:4){
  K[, i] =  tapply(mzs_pspcas95$contributions[, i], ms_scalesh_fac, sum)
}
rownames(K) = levels(ms_scalesh_fac)
Ks = K[rowSums(K[, 1:2]) != 0, 1:2]
dim(Ks)
rox(100*Ks[Ks[,1] != 0, 1], 1)
rox(100*Ks[Ks[,2] != 0, 2], 1)

#demog========
ms_demo = MS[, c(101, 102)]
class(ms_demo)
sapply(ms_demo, class)
sort(unique(ms_demo$age))
table(ms_demo$gender)

#remove 
b = mz_demo$gender
b[b ==0] = NA
table(b)
a = factor(b, labels = c("Male", "Female", "Other"))
anyna(a)

#scoreplot P1 P2 col gender
#not useful
plot(mzs_pspcas95$scores[, 1], mzs_pspcas95$scores[, 2], col = a, pch = 16)


##Boxplot sPCS by Gender====
###not useful--------------
A = data.frame(sPC = c(mzs_pspcas95$scores[, 1:2]), Gender = rep(a, 2), Order = factor(rep(1:2, each = mz_n), labels = paste("PC", 1:2)))
table(A$Order)
mz_n
B = na.omit(A)
ggplot(B, aes(x = Gender, y = sPC, fill = Gender)) + geom_boxplot() + facet_wrap(facets = vars(Order)) 

##Boxplot sPCS by Age====
###USEFUL--------------
a = mz_demo[, "age"]
class(a)
table(a)
length(a)
dim(mzs)
names(MZ)
sum(MZ[, 1:100] ==0)
a[a> 79] = NA
summary(mz_demo[, "age"])
class(a)
names(ms_demo)
range(a)
D = data.frame(sPC = c(mzs_pspcas95$scores[, 1:2]), Age = factor(rep(a, 2)), Order = factor(rep(1:2, each = mz_n), labels = paste("sPC", 1:2))
)
#remove over 80, not reliable
sum(a > 80)
noti = (rep(a, 2) > 80)
E = droplevels(D[!noti,])
table(E$Order)

mz_boxplots_spc12_byAge_pl = ggplot(D, aes(x = Age, y = sPC, fill = Age)) + geom_boxplot() + facet_wrap(facets = vars(Order)) + theme(legend.position = "none", axis.text.x = element_text(angle = 90))

mz_boxplots_spc12_byAge_pl

table(E$Age)

SPCA2:::print.spca(mzs_pspcas95, cols = 1:2)

##boxplots
a = ms_demo[, "age"]
class(a)
sum(a > 80)
a[a > 80] = NA
summary(a)
acut = cut(a, breaks = seq(10, 80, 10))
table(acut)
levels(acut)
anyna(acut)
length(a)
dim(msc)
G = data.frame(sPC = c(mzs_pspcas95$scores[, 1:2]), Age = rep(acut, 2), Order = rep(1:2, each = n_ms), labels = paste("PC", 1:2))

E = droplevels(D[!noti,])

#Not useful
ggplot(na.omit(G), aes(x = Age, y = sPC, fill = Age)) + geom_boxplot() + facet_wrap(facets = vars(Order)) + theme(legend.position = "none", axis.text.x = element_text(angle = 90))

##Young outliers=============
###Useful
ii = (MS$age<= 50) & (mzs_pspcas95$scores[, 2]< -5)
M = MS[ii, mzs_pspcas95$ind[[2]]] 
names(M)

#averages young outliers =======

m = apply(M, 2, mean)
rox(m)
dim(M)
mm = apply(MS[(MS$age < 80), mzs_pspcas95$ind[[2]]], 2, mean)
rox(cbind(m, mm), 2)

names(M)
#averages young by scale
scm = stringr::str_split(names(M), pattern = "_" )
scm = sapply(scm, function(x) x[[1]])
scmf = forcats::as_factor(scm)
scml = fac2list(scmf)
scmlv = vec2list(scm)
all.equal(scml, scmlv)

is.list(scml)
args(lapply)
mt = sapply(scml, FUN = function(i, H)  
  mean(unlist(H[, i])), H = M)

rox(mt, 2)

Mt = sapply(ms_scale_list, FUN = function(i, H) mean(unlist(H[, i])), H = MS[ii, 1:100])

rox(Mt, 2)

#frequencies by gender and age
mcut = cut(MS[ii, 101], breaks = seq(10, 50, 10))
table(mcut)
MM = cbind(M, ageband = mcut, Gender = MS[ii, 102])
sapply(MS[ii, 101:102], table)
names(MM)
H = MM[MM$Gender > 0, 19:20]
Ht = table(H)
Ht
rox(100*table(H)/nrow(H),1)
rox(100*sweep(Ht, 2, colSums(Ht),"/"), 1)
rox(100*sweep(Ht, 1, rowSums(Ht),"/"), 1)
levels(G$Age)
indng = (as.numeric(G$Age) < 5)
rox(table(MM$ageband)/table(droplevels(G$Age[indng])))
