

roxygen2::roxygenise(
  roclets = c("rd", "namespace")
)

{devtools::document()
#  devtools::load_all(path = ".", compile = FALSE, quiet = FALSE)
}
devtools::test()
devtools::test_file("/tests/testthat/helper-spca-fixtures.R")

##

gsub("\\b(ata|aat|atb|ab|abt|atda|atdb|av|atv|vta|vtau|vtv|vtu)C\\b", "\\1", "atdbC" )

gsub("\b(ata|aat|atb|ab|abt|atda|atdb|av|atv|vta|vtau|vtv|vtu)C\b", "\1", "atdbC" )

rewrote guarded versions of:
  
  makeVexpSC() ok
makeCvexpOneCompSC_int() ok
uspcaC() ok
pspcaC() ok
deflT_F() ok
cpcaTC() ok
uspcaTC() ok
pspcaTC() ok
###

X = make_tall_data()
S = stats::cor(X)
load_mat = make_2load_matrix()

aa = make_vexpSC(load_mat, S)
bb = make_vexpSC_OLD(load_mat, S)


fit = new_spca(A = load_mat,  S = S, X = X, method_name = "manual")


A = matrix(1, nrow = 3, ncol = 2)
aa = make_vexpSC(A, S)


new_spca(A, S = S)

new_spca()



Done
new_spca
pca
fixed index
test_methods
power method
spca var_selection
test_spca
test-spca-structure
test_plots
test-compare-plot
test_validation

tt = list.files("C:/Users/merol/Dropbox/Papers/spca_revamp/spca/tests/testthat")
tt = tt[-(1:3)]
pat = "tests/testthat/"
k = 11
testthat::test_file(paste0(pat, tt[k]))


testthat::test_file("tests/testthat/test-new-spca.R")

ll = vector("list", 4)
length(ll)
ll[1] = list(NULL)
length(ll)
ll[[1]] = NULL
ll[1] = NULL

dim(tall_cov$par_grid)
[1] 576   8
names(tall_cov)
time_tall_covOLD = time_tall_cov
rm(time_tall_cov)
sapply(tall_cov, length)
#WARNINGS==================================
table(sapply(tall_cov$error_log, length))
#tc_indw0 = which(sapply(tall_cov$error_log, length) == 0)
tc_indw1 = which(sapply(tall_cov$error_log, length) == 1)
#tc_indw2 = which(sapply(tall_cov$error_log, length) == 2)

tall_cov$error_log[tc_indw1]


par_tall_grid[tc_indw2, ]
391
aa = spca(ho_r, n_comps = 4, 
method = "cspca", var_selection = "step",  stop_criterion = "r2",  
intensive = FALSE, pm_loading = FALSE, pm_varsel = TRUE)

aa$cpp_time_wall
aa$ti
391   0.9       4  uspca          step             r2      TRUE      FALSE      TRUE

##TIME--------------------------------
sapply(tall_cov, class)
summary(tall_cov$time_sec)
summary(tall_cov$cpp_time_wall)
summary(tall_cov$elapsed_time)

summary(tall_cov$cpp_time_wall[tall_cov$cpp_time_wall > 393901])

tc_indltime  = which(tall_cov$cpp_time_wall > 700000)
par_tall_grid[tc_indltime , ]

tc_indstpint = which((tall_cov$par_grid$var_selection == "step") & (tall_cov$par_grid$intensive == TRUE))
table(sapply(tall_cov$warn_log[tc_indstpint], length))
sapply(tall_cov$warn_log[tc_indstpint], length)

tc_inbkwpint = which((tall_cov$par_grid$var_selection == "bkw") & (tall_cov$par_grid$intensive == TRUE))
length(tc_inbkwpint)

hh = (sapply(tall_cov$warn_log[tc_inbkwpint], length))
ii = which(hh == 1)
summary(tall_cov$res_list[[ii[3]]])

par_tall_grid[ii, ]
dim(tall_cov$par_grid)

576/96       

aa = spca(ho_r, n_comps = 2, var_selection = "bkw", intensive = TRUE)
summary(aa)
bb = spca(ho_r, n_comps = 2, var_selection = "step", intensive = TRUE)
summary(bb)
cc = spca(ho_r, n_comps = 2, var_selection = "fwd", intensive = TRUE)
summary(cc)

all.equal(aa$loadings, cc$loadings)
    



#FAT==============

dd = spca(tho, n_comps = 4)
dd$cpp_time_wall


