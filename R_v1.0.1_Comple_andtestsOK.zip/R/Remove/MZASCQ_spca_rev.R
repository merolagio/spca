MSSCQ
REMOVE all zeroes
#MS and all files with names, scales, lookup
#MS already questions reversed and column sorted
load( "msc_basic.Rdata", verbose = T)
load("C:/Users/merol/Dropbox/Papers/spca_revamp/spca/R/Remove/MZA_basic.Rdata", verbose = T)

load("C:/Users/merol/Dropbox/Papers/spca_revamp/spca/R/Remove/MZ_basic.Rdata", verbose = T)

getwd()

remo = c(objects(pattern = "^MS" ), objects(pattern = "^ms", ),
         objects(pattern = "^MZ" ), objects(pattern = "^mz" )
         )
rm(list = remo)
objects(pattern = "^MS" )
#for PMtuto
save(list = c("ms", "ms_lookup", "ms_scalesh_fac"), file = "ms_PM_tuto.Rdata")

dim(MS)
dim(MZ)
dim(MZA)

anyNA(MS)

ms_scalesh_names = unique(MS_lookup$scaleSH)
ms_scalesh_list = MS_scale_list
names(ms_scalesh_list) = ms_scalesh_names
ms_scale_fac = factor(rep(1:20, each = 5), labels = ms_scale_names)
ms_scalesh_fac = factor(rep(1:20, each = 5), labels = ms_scalesh_names)
ms_scalesh_list
ms_scalesh_fac
#to here

MS_scalesh_list = MS_scale_list
names(MS_scalesh_list) = ms_scalesh_names

ms_scale_fac = factor(rep(1:20, each = 5), labels = ms_scale_names)
ms_scalesh_fac = factor(rep(1:20, each = 5), labels = ms_scalesh_names)
ms_scale_list


numzeros = apply(MS[, 1:100] == 0, 1, sum)
summary(numzeros)
mean(numzeros > 0)
table(numzeros[numzeros>5])

sum(numzeros > 3)#700
mean(numzeros > 3)#4%
indzeros = which(numzeros > 0)


length(indzeros)
MZA = MS[-indzeros, ]
names(MZA)
dim(MZA)
zz = rowSums((MZA[, 1:100] == 0))
table(zz)

4693 12992

##scale vars-----------------

ms_scalesh_names = unique(MS_lookup$scaleSH)
ms_scalesh_list = MS_scale_list
names(ms_scalesh_list) = ms_scalesh_names
ms_scale_fac = factor(rep(1:20, each = 5), labels = ms_scale_names)
ms_scalesh_fac = factor(rep(1:20, each = 5), labels = ms_scalesh_names)


ms_scalesh_names_fac = forcats::as_factor(ms_scalesh_names)
levels(ms_scalesh_names_fac)
# MZA_vars = apply(MZA[, 1:100], 2, var)
# 
# dfvar = data.frame(Item = forcats::as_factor(colnames(MZA)[1:100]), variance = MZA_vars, Scale = MS_lookup$scaleSH)
# 
# ggplot(dfvar, aes(Item, y = variance, fill = Scale)) + geom_bar(stat = "identity", position = "dodge") + theme(axis.text.x = element_text(angle = 90), legend.position = "none")

#make matrice==============

mza_demo = MZA[, 101:102]

mza_n = nrow(MZA)
mza_p = ncol(MZA) - 2

# mzac = scale(MZA[, 1:100], scale = F)
# colnames(mzac) = colnames(MZA)[1:100]
# mza_v = var(mzac)
mzas = scale(MZA[, 1:100])
colnames(mzas) = colnames(MZA)[1:100]
mza_r = cor(mzas)

#corplot---------------------------
mza_corplot_pl = plotcor4(mza_r, vargroup_list = ms_scale_fac, separateblocks = T, expandTop = 0.05, blocknames = ms_scalesh_names, blocknamesvjust = -0.5, blocknamessize = 4,  side_axis_labels =  F, rtn = T, plt = T)

mza_corplot_pl 
tuto_save(plname = "mza_corplot_pl", w = 8, h = 8)
#+  #theme(plot.margin = unit(c(top = 2, right = 1, bottom = -1, left = 1), "lines")) + 
#   scale_y_discrete(expand = expansion(mult = c(0.025, 0.1))) + 
#   coord_cartesian(clip = "off") #


# gg <- mza_r[upper.tri(mza_r)]
# summary(gg)
# summary(abs(gg))


save(list = c("MZA", "mza_demo", "MS_lookup","ms_scale_fac", "ms_scale_list", "ms_scale_names", "ms_scalesh_fac", "ms_scalesh_list", "ms_scalesh_names"), file = "MZA_basic.Rdata")
#Eigen R===========

mzar_ee = eigen(mza_r, symmetric = T)
rox(mzar_ee$values[1:30], 1)
rox(100*mzar_ee$values[1:30]/sum(mzar_ee$values), 1)
rox(100*cumsum(mzar_ee$values[1:30])/sum(mzar_ee$values), 1)

args(scree_watc_plot)
mza_scree_wact_pl = scree_watc_plot(mzar_ee$values, n = mza_n, wa_nfit_line = 96, wa_cor = T)
mza_scree_wact_pl
tuto_save(plname = "mza_scree_wact_pl", w = 12, h = 6)


#PCA==============

mzas_pca = SPCA2::pca(mzas, ncomps = 4 )
summary(mzas_pca)


mzas_pca_contr_pl = SPCA2:::plot.spca(mzas_pca, returnplot = T, vargroups = ms_scalesh_fac, varnames = F, colourscale = "ggplot", legendPosition = "right", stripnames = paste("Component", 1:4), produceplot = F, ) + scale_y_continuous(labels = scales::percent) + labs(x = "item")

mzas_pca_contr_pl

tuto_save("mzas_pca_contr_pl", w = 10, h = 4)


#SPCA===================
#slow 17k obs x 100 vars
library(SPCA2)
##95%======================

sttime = Sys.time()
mzas_pspcas95 = pspca2(mzas, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "s", scalex = FALSE) 

endtime = Sys.time()
sttime - endtime


mzas_pspcas90 = pspca2(mzas, alpha = 0.90, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "s", scalex = FALSE) 

summary(mzas_pspcas95, cols = 1:4, variance_metrics = "both")

PMlsspca:::summary.spca(mzas_pspcas90, variance_metrics = "both")

rox(diag(cor(mzas_pca$scores, mzas_pspcas90$scores)))
capture.output(rox(mzas_pspcas90$corComp))


rox(mzas_pspcas95$vexp/mzas_pspcas95$vexpPC)

mzas_pspcaf95 = pspca2(mzas, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "f", scalex = FALSE) 



mzas_pspcab95 = pspca2(mzas, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "b", scalex = FALSE) 

mzas_uspcaf95 = pspca2(mzas, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "u", subsearch = "f", scalex = FALSE) 

mzas_cspcaf95 = pspca2(mzas, alpha = 0.95, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "c", subsearch = "f", scalex = FALSE) 

args(SPCA2::SPCA)
mzas_cSPCAf95 = SPCA2::SPCA(mzas, alpha = 0.95,  ncomps = 4,  method = "c", varselection =  "f") 
mzas_uSPCAf95 = SPCA2::SPCA(mzas, alpha = 0.95,  ncomps = 4,  method = "u", varselection =  "f", checkrank = T) 


summary(mzas_pspcas95)
summary(mzas_pspcaf95)
summary(mzas_pspcab95)

capture.output(
cbind(
PMlsspca:::summary.spca(mzas_uspcaf95, variance_metrics = "both"),
PMlsspca:::summary.spca(mzas_cspcaf95, variance_metrics = "both"),
PMlsspca:::summary.spca(mzas_pspcaf95, variance_metrics = "both")
), file = "clipboard"
)

capture.output(
rox(rbind(
  diag(cor(mzas_pca$scores, mzas_uspcaf95$scores)),
  diag(cor(mzas_pca$scores, mzas_cspcaf95$scores)),
  diag(cor(mzas_pca$scores, mzas_pspcaf95$scores))), 2
), file = "clipboard"
)
summary(mzas_cSPCAf95)
summary(mzas_uSPCAf95)

rox(cbind(mzas_cspcaf95$corComp, mzas_cSPCAf95$corComp))

mzas_uspcaf90 = pspca2(mzas, alpha = 0.90, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "u", subsearch = "f", scalex = FALSE) 

mzas_cspcaf90 = pspca2(mzas, alpha = 0.90, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "c", subsearch = "f", scalex = FALSE) 

mzas_pspcaf90 = pspca2(mzas, alpha = 0.90, maxcard = 0, ncomps = 4, ndbyvexp = 0, method = "p", subsearch = "f", scalex = FALSE) 


FAI TABELLA PER APPENDIX

capture.output(
  cbind(
    PMlsspca:::summary.spca(mzas_uspcaf90, variance_metrics = "both"),
    PMlsspca:::summary.spca(mzas_cspcaf90, variance_metrics = "both"),
    PMlsspca:::summary.spca(mzas_pspcaf90, variance_metrics = "both")
  ), file = "clipboard"
)

capture.output(
  rox(rbind(
    diag(cor(mzas_pca$scores, mzas_uspcaf90$scores)),
    diag(cor(mzas_pca$scores, mzas_cspcaf90$scores)),
    diag(cor(mzas_pca$scores, mzas_pspcaf90$scores))), 2
  ), file = "clipboard"
)


summary(mzas_pspcas90)
mza_p

13/100

##plot loads------------------------

mzas_pspcas95_2Contr_pl = plot(mzas_pspcas95, nplot = 2, varnames = F, vargroups = ms_scalesh_fac, onlynonzero = F, plottype = "b", colourscale = "ggplot", legendPosition = "right", returnplot = T, produceplot = F)  + scale_y_continuous(labels = scales::percent) + labs(x = "item")


mzas_pspcas95_2Contr_pl

tuto_save("mzas_pspcas95_2Contr_pl", w = 16, h = 4)

ms_sc

mzas_pspcas95_contr_pl = SPCA2:::plot.spca(mzas_pspcas95, nplot = 4, onlynonzero = T, varnames = F, stripnames = paste("Component", 1:4), legendPosition = "right", vargroups = ms_scalesh_fac, colourscale = "ggplot", returnplot = T, produceplot = F)  + scale_y_continuous(labels = scales::percent) + labs(x = "item") 

mzas_pspcas95_contr_pl


tuto_save("mzas_pspcas95_contr_pl", w = 10, h = 5)


##90%=================
mzas_pspcas90_load_pl = SPCA2:::plot.spca(mzas_pspcas90, nplot = 4, onlynonzero = T, varnames = F, legendPosition = "right", vargroups = ms_scalesh_fac, colourscale = "ggplot", returnplot = T, produceplot = F)  + scale_y_continuous(labels = scales::percent) + labs(x = "item")

mzas_pspcas90_load_pl

mzas_pspcas95_2Scoreplot_pl = SPCA2::plot_scores(scorelist = mzas_pspcas95$scores, pcs = mzas_pca$scores,  nplot = 2, methodsnames = "pSPCA 95%", addcor = T, linesize = 1, pointsize = 0.6, textsize = 7, rtn = T)

tuto_save("mzas_pspcas95_2Scoreplot_pl", h = 4.5)


##Tables-----------------------

aa = comp.spca25(smpc = mzas_pspcas95, compareto = list(mzas_pspcas90), ncomp = 4, only.nonzero = T, methodsnames = c("pSPCA 95%", "pSPCA 90%"), vargroups = ms_scalesh_fac, plotvar = F, plotload = F, pointload = T, shortnamescomp = F, rtnTables = T)


wrt_clip(aa$Summary[-5, ])





#not used
###aggregated=======================

##plot contr by scale=================
aggregateBy
mzas_aggreg_contr = make_contByscale(mzas_pspcas95$contributions, vargroups = ms_scale_fac, ncomp = 4)

ms_scalesh_names_fac = forcats::as_factor((ms_scalesh_names))

length(c(mzas_aggreg_contr))
write.table(mzas_aggreg_contr, file = "clipboard", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)


BB = data.frame(Contribution = c(mzas_aggreg_contr), Scale = rep(ms_scalesh_names_fac, 4), Component = factor(rep(1:4, each = length(ms_scalesh_names)), labels = paste("Component", 1:4)) )

thisTheme = ggplot2::theme_light() + ggplot2::theme(legend.position = "right", legend.title = element_blank(), legend.text = element_text(colour = "black", size = 12), legend.key.size = ggplot2::unit(0.35, "cm"), legend.key.width = ggplot2::unit(0.25, "cm"), panel.border = element_rect(colour = "black", linewidth = 1), panel.background = element_rect(fill = "white", colour = "black", linetype = 1), strip.text = element_text(size = 18, color = "black"), strip.background = element_rect(fill = "white", color = "black", linetype = 1, linewidth = rel(1))) 

mzas_pspcas95_contrByScale_pl = ggplot(BB, aes(x = Scale, y = Contribution, fill = Scale)) + geom_bar(stat = "identity", position = "dodge") + facet_wrap(facets = vars(Component), ncol = 2) + scale_y_continuous(labels = scales::percent) + this_theme + 
 geom_hline(yintercept = 0, colour = "black")

tuto_save("mzas_pspcas95_contrByScale_pl", w = 10, h = 5)



M = mzas_aggreg_contr[, c(1,4,7)]  
M
rox(sort(M[,1]), 0)
rox(tapply(M[,1], M[, 1] < 0, sum), 0)

k = 2
rox(sort(M[,k]), 0)
rox(tapply(M[,k], M[, k] < 0, sum), 0)

##corr scores=======================
wrt_clip(
cbind(
rox(rbind(mzas_pspcas95$corComp, diag(cor(mzas_pca$scores, mzas_pspcas95$scores))))
,
rox(rbind(mzas_pspcas90$corComp, diag(cor(mzas_pca$scores, mzas_pspcas90$scores))))
)
)



##contr 1-2-----------------

#2 cross loads
# 51 sexual_motivation     SMT
# 95 sexual_depression      SD

ind195 = sort(mzas_pspcas95$ind[[1]])
ind295 = sort(mzas_pspcas95$ind[[2]])
intersect(ind195, ind295)
MS_lookup[c(51, 95), ]

#no cross loads
ind190 = sort(mzas_pspcas90$ind[[1]])
ind290 = sort(mzas_pspcas90$ind[[2]])
intersect(ind190, ind290)


inda95 = sort(unique(unlist(mzas_pspcas95$ind[1:2])))
inda90 = sort(unique(unlist(mzas_pspcas90$ind[1:2])))
length(inda95)
length(inda90)

#file with both 95 and 90
inda = sort(union(inda95, inda90))
length(inda)

B = matrix(0, 100, 6)
for(i in 1:2){
  B[, (1:3) + 3*(i - 1)] = cbind(rox(cbind(mzas_pca$contributions[, i], mzas_pspcas95$contributions[, i], mzas_pspcas90$contributions[, i])))
}
colnames(B) = paste0(rep(c("PCA", "SPCA 95%", "SPCA 90%"), 2), rep(1:2, each = 3))
B = as.data.frame(B[inda, ])
B[1:10,]

# B = as.data.frame(rox(cbind(mzas_pca$contributions[, 1:2], mzas_pspcas95$contributions[, 1:2], mzas_pspcas90$contributions[, 1:2])[inda, ]))

names(MS_lookup)
#A = MS_lookup[inda, 1:3]
A = cbind(Item = MS_lookup[inda, 1], scale = MS_lookup[inda, 4], B)
rownames(A) = NULL
mzas_contr_12_table = A


write.table(A, "clipboard", sep = "\t", row.names = FALSE, col.names = TRUE, quote = FALSE)

D = cbind(summary(mzas_pca, cols = 1, rtn = T, prn = F), summary(mzas_pspcas95, cols = 1, rtn = T, prn = F), summary(mzas_pspcas90, cols = 1, rtn = T, prn = F),
          summary(mzas_pca, cols = 2, rtn = T, prn = F)[, 2], summary(mzas_pspcas95, cols = 2, rtn = T, prn = F)[, 2], summary(mzas_pspcas90, cols = 2, rtn = T, prn = F)[, 2])


D
write.table(D, "clipboard", sep = "\t", row.names = FALSE, col.names = TRUE, quote = FALSE)

summary(mzas_pspcas95, cols = 4, rtn = F, prn = T)

D = cbind(summary(mzas_pca, cols = 4, rtn = T, prn = F)[, 3], summary(mzas_pspcas95, cols = 4, rtn = T, prn = F)[, 3], summary(mzas_pspcas90, cols = 4, rtn = T, prn = F)[, 3],
          summary(mzas_pca, cols = 4, rtn = T, prn = F)[, 4], summary(mzas_pspcas95, cols = 4, rtn = T, prn = F)[, 4], summary(mzas_pspcas90, cols = 4, rtn = T, prn = F)[, 4])

D
write.table(D, "clipboard", sep = "\t", row.names = FALSE, col.names = TRUE, quote = FALSE)



#file with only 95 

#primi 2 loads=====================
inda95 = sort(unique(unlist(mzas_pspcas95$ind[1:2])))

# fln = "Tables/mzas_pspca_95_2cont.csv"
# write.table(cbind(MS_lookup[inda95, 1:3], mzas_pspcas95$contributions[inda95, 1:2]), file = fln, row.names = F, sep = "\t")
# write.table(x = "Summaries", file = fln, append = T, row.names = F, col.names = F)
# write.table(summary(mzas_pspcas95, cols = 1:2, rtn = T, prn = F), file = fln, row.names = T, sep = "\t", append = T)


#abess spca ================

mzas_abess = abess::abesspca(mza_r, type = "predictor", sparse.type = "kpc", 
                            cor = F, kpc.num = 4)#, support.size = rep(1:20, 6))  

dim(mzas_abess$coef[[1]])
length(mzas_abess$coef)
#abess::extract()


dim(mzas_abess$coef[[1]])
colSums(abs(as.matrix(mzas_abess$coef[[1]])) > 0)
mzas_abess$coef[[2]]

mzas_pspcaf95$card
objects(pattern = "^ms")

##make abess spca=================
cc = sapply(1:4, function(i, ab, sp) ab[[i]][, sp[i]],
            ab = mzas_abess$coef, sp = mzas_pspcas95$card)

cc[, 1:3 ] = -cc[, 1:3 ]
dim(cc)

aa = cbind(mzas_abess$coef[[1]][, mzas_pspcas95$card[1]], mzas_abess$coef[[2]][, mzas_pspcas95$card[2]])

all.equal(cc, aa)
args(SPCA2::new_spca)
mzas_abess.spca =  SPCA2::new_spca(cc, mza_r, mzas, method = "abess")
names(mzas_abess.spca)

summary(mzas_abess.spca)

#compare contrib with pspca
rox(cbind(mzas_pspcas95$loadings[, 1], cc[, 1]))
dim(mzas_abess$coef[[1]])
aa = cbind(mzas_abess$coef[[1]][, mzas_pspcas95$card[1]], mzas_abess$coef[[2]][, mzas_pspcas95$card[2]])
dim(aa)
rox(aa[rowSums(aa) != 0, ])
colSums(abs(cc)> 0)

make_contByscale(mzas_abess.spca$contributions, ms_scale_fac, only.nonzero = T)

rox(mzas_abess.spca$corComp)

rox(cor(mzas_abess.spca$scores, mzas_pca$scores))


mza_p
dim(cc)
ind1 = which(mzas_pspcas95$contributions[, 1] != 0)
length(ind1)
inda1 = which(cc[, 1] != 0)
length(inda1)


View(cc)

#cc = -cc
#mzas_abess.spca$vif

rox(cor(mzas_abess.spca$scores))
SPCA2:::plot.spca(mzas_abess, onlynonzero = F)
class(mzas_abess.spca)

summary(mzas_abess.spca)

write.table(summary(mzas_abess.spca, rtn = T), "clipboard", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

rbind(summary(mzas_pspcas95), summary(mzas_abess.spca))

rbind(summary(mzas_pspcas90), summary(mzas_abess.spca))

rox(cor(mzas_abess.spca$scores, cbind(mzas_abess.spca$scores, mzas_pca$scores, mzas_pspcas95$scores)))

plot(mzas_abess.spca, colourscale = "ggplot", vargroups = ms_scalesh_fac)
length(ms_scale_list)
MS_lookup[mzas_abess.spca$ind[[1]], ]
dim(MS_lookup)
bb = tcrossprod(x, t(aa))
dim(bb)
sum((rmsc)^2)
rox(cor(mzas_abess.spca$scores))


##aggregated by scale====================


M = make_contByscale(cbind(mzas_pca$contributions, mzas_pspcas95$contributions, mzas_pspcas90$contributions), ms_scalesh_fac)  
dim(M)

rownames(M)
A = matrix(0, 20, 12)
for(k in 1:4){
  # print(rbind((1:3) + (k - 1)* 3,
  #       c(seq(1, 9, 4) +(k - 1))))
A[, (1:3) + (k - 1)* 3] = M[, c(seq(1, 9, 4) +(k - 1))]
}
rownames(A) = ms_scalesh_names
dim(A)
A
mzas_aggrContr  = A

rownames(mzas_aggrContr)
mzas_aggrContr

write.table(mzas_aggrContr, "clipboard", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

mzas_aggrContr[1:10, 1:3]

##with abess=============

N = make_contByscale(mzas_abess.spca$contributions, ms_scalesh_fac, only.nonzero = F)  
dim(N)
dim(M)
rownames(N)

write.table(N, "clipboard", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)


A = matrix(0, 20, 12)
for(k in 1:4){
  # print(rbind((1:3) + (k - 1)* 3,
  #       c(seq(1, 9, 4) +(k - 1))))
  A[, (1:3) + (k - 1)* 3] = M[, c(seq(1, 9, 4) +(k - 1))]
}
rownames(A) = ms_scalesh_names
dim(A)
A
mzas_aggrContr  = A

rownames(mzas_aggrContr)
mzas_aggrContr

write.table(mzas_aggrContr, "clipboard", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

mzas_aggrContr[1:10, 1:3]




#sPCs by demog ====================






#demog========



## Questions ---------------------
"I70 (SS, ``I’m concerned about how the sexual aspects of my life appear to others.'') contributes 13\% by itself, and it is the single most influential SS item here.
"
"I62 (SE, ``I am able to cope with and to handle my own sexual needs and wants.'') contributes 10\% by itself, anchoring the SE share.
"
"I83 (FOS, ``I am very aware of the sexual aspects of myself (e.g. habits, thoughts, beliefs).'') contributes 10\% by itself, anchoring the FOS share.
"
ms_demo = MS[, c(101, 102)]
class(ms_demo)
sapply(ms_demo, class)
sort(unique(ms_demo$age))
table(ms_demo$gender)

#remove 
class(mza_demo$gender)
b = mza_demo$gender
b[b ==0] = NA
table(b)
a = factor(b, labels = c("Male", "Female", "Other"))
anyna(a)
range(mza_demo$age)
b = mza_demo$age 
b[b > 79] = NA
range(na.omit(b))
ageband = cut(x = b, breaks = seq(10, 80, 10))
table(ageband)
#62, 70, 83 


G = MZA[, c(62, 70, 83)]
rox(sapply(G, table)/mza_n)
colMeans(G)
class(G$SE_I62) = "numeric"
class(G$SS_I70) = "numeric"
class(G$FOS_I830) = "numeric"
Gmat = cbind(G, Gender = a, age = b, age_band = ageband)
class(Gmat)

G_df = data.frame(agreement = c(unlist(G)), Question = factor(rep(1:3, each = mza_n), labels = paste0("I", c(62, 70, 83))), Gender = rep(a, 3), Age = rep(b, 3), Age_band = rep(ageband, 3))

#all Q by Gender
ii = which(is.na(G_df$Gender))
mz_allq_byge_pl = ggplot(G_df[-ii, ], aes(x = Gender, y = agreement, fill = Gender)) + geom_boxplot() +  facet_wrap(facets = vars(Question)) + theme(axis.text.x = element_text(angle = 90))

mz_allq_byge_pl

buono
#all Q by ageband 
jj = which(is.na(G_df$Age_band))
mz_allq_byageb_pl = ggplot(G_df[-jj, ], aes(x = Age_band, y = agreement, fill = Age_band)) + geom_boxplot() +  facet_wrap(facets = vars(Question)) + theme(axis.text.x = element_text(angle = 90))

mz_allq_byageb_pl

sum(is.na(Gmat$age)) 
sum(is.na(Gmat$Gender))
sum(is.na(Gmat$age) | is.na(Gmat$Gender))

kkb = which(is.na(Gmat$age) | is.na(Gmat$Gender))
kkage = which(is.na(Gmat$age))
kkge = which(is.na(Gmat$Gender))
names(Gmat)
class(Gmat$age)

#I70 by age and gender
q70_byAgeGen_pl = ggplot(Gmat[-kkage, ], aes(x = as.factor(age), y = SS_I70, fill = age_band)) + geom_boxplot()+   theme(axis.text.x = element_text(angle = 90)) + labs(title = "I70 `sexual life appear to others' by age and Gender")  #+ facet_wrap(vars(Gender))

#No
ggplot(Gmat[-kkge, ], aes(x = as.factor(Gender), y = SS_I70, fill = Gender)) + geom_boxplot()+   theme(axis.text.x = element_text(angle = 90)) + labs(title = "I70 `sexual life appear to others' by age and Gender")  #+ facet_wrap(vars(Gender))

ggplot(Gmat[-kkb, ], aes(x = as.factor(age_band), y = SS_I70, fill = Gender)) + geom_boxplot()+   theme(axis.text.x = element_text(angle = 90)) + labs(title = "I70 `sexual life appear to others' by age and Gender")  + facet_wrap(vars(Gender))

rox(tapply(G$SE_I62[-jj], Gmat$age_band[-jj], mean), 2)
rox(tapply(G$SS_I70[-jj], Gmat$age_band[-jj], mean), 2)
rox(tapply(G$FOS_I83[-jj], Gmat$age_band[-jj], mean), 2)

names(G)
#scoreplot P1 P2 col gender
#not useful
plot(mzas_pspcas95$scores[, 1], mzas_pspcas95$scores[, 2], col = a, pch = 16)


##Boxplot sPCS by Gender====
###not useful--------------
A = data.frame(sPC = c(mzas_pspcas95$scores[, 1:2]), Gender = rep(a, 2), Order = factor(rep(1:2, each = mza_n), labels = paste("PC", 1:2)))
table(A$Order)
mza_n
B = na.omit(A)
ggplot(B, aes(x = Gender, y = sPC, fill = Gender)) + geom_boxplot() + facet_wrap(facets = vars(Order)) 

##Boxplot sPCS by Age====
###USEFUL--------------
a = mza_demo[, "age"]
class(a)
table(a)
length(a)
dim(mzas)
names(MZA)
sum(MZA[, 1:100] ==0)
a[a> 79] = NA
summary(mza_demo[, "age"])
class(a)
names(ms_demo)
range(a)
D = data.frame(sPC = c(mzas_pspcas95$scores[, 1:2]), Age = factor(rep(a, 2)), Order = factor(rep(1:2, each = mza_n), labels = paste("sPC", 1:2))
)
#remove over 80, not reliable
sum(a > 80)
noti = (rep(a, 2) > 80)
E = droplevels(D[!noti,])
table(E$Order)

mza_boxplots_spc12_byAge_pl = ggplot(D, aes(x = Age, y = sPC, fill = Age)) + geom_boxplot() + facet_wrap(facets = vars(Order)) + theme(legend.position = "none", axis.text.x = element_text(angle = 90))

mza_boxplots_spc12_byAge_pl

table(E$Age)

SPCA2:::print.spca(mzas_pspcas95, cols = 1:2)

##boxplots
a = ms_demo[, "age"]
class(a)
sum(a > 80)
a[a > 80] = NA
summary(a)
acut = cut(a, breaks = seq(10, 80, 10))
table(acut)
levels(acut)
anyna(acut)
length(a)
dim(msc)
G = data.frame(sPC = c(mzas_pspcas95$scores[, 1:2]), Age = rep(acut, 2), Order = rep(1:2, each = n_ms), labels = paste("PC", 1:2))

E = droplevels(D[!noti,])

#Not useful
ggplot(na.omit(G), aes(x = Age, y = sPC, fill = Age)) + geom_boxplot() + facet_wrap(facets = vars(Order)) + theme(legend.position = "none", axis.text.x = element_text(angle = 90))

##Young outliers=============
###Useful
ii = (MS$age<= 50) & (mzas_pspcas95$scores[, 2]< -5)
M = MS[ii, mzas_pspcas95$ind[[2]]] 
names(M)

#averages young outliers =======

m = apply(M, 2, mean)
rox(m)
dim(M)
mm = apply(MS[(MS$age < 80), mzas_pspcas95$ind[[2]]], 2, mean)
rox(cbind(m, mm), 2)

names(M)
#averages young by scale
scm = stringr::str_split(names(M), pattern = "_" )
scm = sapply(scm, function(x) x[[1]])
scmf = forcats::as_factor(scm)
scml = fac2list(scmf)
scmlv = vec2list(scm)
all.equal(scml, scmlv)

is.list(scml)
args(lapply)
mt = sapply(scml, FUN = function(i, H)  
  mean(unlist(H[, i])), H = M)

rox(mt, 2)

Mt = sapply(ms_scale_list, FUN = function(i, H) mean(unlist(H[, i])), H = MS[ii, 1:100])

rox(Mt, 2)

#frequencies by gender and age
mcut = cut(MS[ii, 101], breaks = seq(10, 50, 10))
table(mcut)
MM = cbind(M, ageband = mcut, Gender = MS[ii, 102])
sapply(MS[ii, 101:102], table)
names(MM)
H = MM[MM$Gender > 0, 19:20]
Ht = table(H)
Ht
rox(100*table(H)/nrow(H),1)
rox(100*sweep(Ht, 2, colSums(Ht),"/"), 1)
rox(100*sweep(Ht, 1, rowSums(Ht),"/"), 1)
levels(G$Age)
indng = (as.numeric(G$Age) < 5)
rox(table(MM$ageband)/table(droplevels(G$Age[indng])))
